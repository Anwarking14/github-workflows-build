package com.example.geminiai.core
import org.junit.Assert.*
import org.junit.Test
class RiskManagerTest {
 private val c=RiskConfig()
 private fun s(age:Long=100,consent:Boolean=true)=RiskSnapshot(0.5,0.0,1,0,age,true,consent)
 @Test fun passesWhenChecksPass(){assertTrue(RiskManager.canSubmit(c,s()))}
 @Test fun rejectsStaleData(){assertFalse(RiskManager.canSubmit(c,s(age=5000)))}
 @Test fun rejectsNoConsent(){assertFalse(RiskManager.canSubmit(c,s(consent=false)))}
 @Test fun rejectsOverStake(){assertFalse(RiskManager.canSubmit(c,RiskSnapshot(2.0,0.0,1,0,100,true,true)))}
}
