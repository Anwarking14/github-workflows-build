package com.example.geminiai.core
import org.junit.Assert.*
import org.junit.Test
class AiResponseValidatorTest {
 @Test fun acceptsValidResponse(){assertNotNull(AiResponseValidator.parse("""{"direction":"UP","confidence":0.72,"reasoning":"Positive momentum","risk_level":"MEDIUM","recommendation":"BUY","data_quality":"GOOD"}"""))}
 @Test fun rejectsInvalidConfidence(){assertNull(AiResponseValidator.parse("""{"direction":"UP","confidence":7,"reasoning":"x","risk_level":"LOW","recommendation":"BUY","data_quality":"GOOD"}"""))}
 @Test fun rejectsMalformedJson(){assertNull(AiResponseValidator.parse("not json"))}
}
