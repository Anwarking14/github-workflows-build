package com.example.geminiai.core
data class AiAnalysis(val direction:String,val confidence:Double,val reasoning:String,val riskLevel:String,val recommendation:String,val dataQuality:String)
data class Signal(val direction:String,val reason:String,val confidence:Double=0.0)
data class RiskConfig(val maxStake:Double=1.0,val maxDailyLoss:Double=10.0,val maxTrades:Int=20,val maxConsecutiveLosses:Int=3)
data class RiskSnapshot(val stake:Double,val dailyLoss:Double,val tradesThisSession:Int,val consecutiveLosses:Int,val dataAgeMillis:Long,val expirySupported:Boolean,val liveConsent:Boolean)
