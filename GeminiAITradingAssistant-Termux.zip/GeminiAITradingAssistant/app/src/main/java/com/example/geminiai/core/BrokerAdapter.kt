package com.example.geminiai.core
interface BrokerAdapter {
 suspend fun connect():BrokerResult
 suspend fun getMarketData(asset:String):BrokerResult
 suspend fun getAccountStatus():BrokerResult
 suspend fun getSupportedAssets():BrokerResult
 suspend fun getSupportedExpiries(asset:String):BrokerResult
 suspend fun placeOrder(request:OrderRequest):BrokerResult
 suspend fun getOrderStatus(orderId:String):BrokerResult
 suspend fun closeConnection()
}
data class OrderRequest(val asset:String,val direction:String,val stake:Double,val expirySeconds:Int,val idempotencyKey:String)
data class BrokerResult(val success:Boolean,val message:String,val orderId:String?=null)
class UnavailableBrokerAdapter:BrokerAdapter {
 private fun no()=BrokerResult(false,"Live integration unavailable: official authorized broker API not configured.")
 override suspend fun connect()=no()
 override suspend fun getMarketData(asset:String)=no()
 override suspend fun getAccountStatus()=no()
 override suspend fun getSupportedAssets()=no()
 override suspend fun getSupportedExpiries(asset:String)=no()
 override suspend fun placeOrder(request:OrderRequest)=no()
 override suspend fun getOrderStatus(orderId:String)=no()
 override suspend fun closeConnection(){}
}
