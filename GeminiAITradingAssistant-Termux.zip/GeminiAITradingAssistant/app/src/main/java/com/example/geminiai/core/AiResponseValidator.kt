package com.example.geminiai.core
import org.json.JSONObject
object AiResponseValidator {
 fun parse(json:String):AiAnalysis? = try {
  val o=JSONObject(json); val d=o.optString("direction").uppercase(); val c=o.optDouble("confidence",Double.NaN)
  val r=o.optString("reasoning"); val risk=o.optString("risk_level").uppercase()
  val rec=o.optString("recommendation").uppercase(); val q=o.optString("data_quality").uppercase()
  if(d !in setOf("UP","DOWN","WAIT") || c.isNaN() || c !in 0.0..1.0 || r.isBlank() ||
   risk !in setOf("LOW","MEDIUM","HIGH") || rec !in setOf("BUY","SELL","WAIT") || q !in setOf("GOOD","FAIR","POOR")) null
  else AiAnalysis(d,c,r,risk,rec,q)
 } catch(_:Exception){null}
}
