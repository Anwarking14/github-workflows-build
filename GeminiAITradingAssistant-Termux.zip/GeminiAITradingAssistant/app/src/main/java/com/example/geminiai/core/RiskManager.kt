package com.example.geminiai.core
object RiskManager {
 fun canSubmit(c:RiskConfig,s:RiskSnapshot,maxDataAgeMillis:Long=3000L):Boolean =
  s.stake>0 && s.stake<=c.maxStake && s.dailyLoss<c.maxDailyLoss &&
  s.tradesThisSession<c.maxTrades && s.consecutiveLosses<c.maxConsecutiveLosses &&
  s.dataAgeMillis in 0..maxDataAgeMillis && s.expirySupported && s.liveConsent
}
