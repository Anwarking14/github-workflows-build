package com.example.geminiai.core
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit
/** Optional Gemini API client. Use a backend proxy for production credentials. */
class GeminiClient(private val apiKey:String,private val model:String="gemini-2.0-flash") {
 private val client=OkHttpClient.Builder().callTimeout(20,TimeUnit.SECONDS).build()
 suspend fun analyze(chartDescription:String):AiAnalysis?=withContext(Dispatchers.IO) {
  if(apiKey.isBlank()||chartDescription.isBlank()) return@withContext null
  val prompt="Analyze only this chart description. If data is insufficient use WAIT and POOR quality. Return JSON keys direction (UP/DOWN/WAIT), confidence (0..1), reasoning, risk_level (LOW/MEDIUM/HIGH), recommendation (BUY/SELL/WAIT), data_quality (GOOD/FAIR/POOR). Confidence is not guaranteed. Description: $chartDescription"
  val body=JSONObject().put("contents",JSONArray().put(JSONObject().put("parts",JSONArray().put(JSONObject().put("text",prompt)))))
   .put("generationConfig",JSONObject().put("responseMimeType","application/json")).toString().toRequestBody("application/json".toMediaType())
  val req=Request.Builder().url("https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent").addHeader("x-goog-api-key",apiKey).post(body).build()
  try { client.newCall(req).execute().use { res ->
   if(!res.isSuccessful) return@withContext null
   val raw=res.body?.string()?:return@withContext null
   val txt=JSONObject(raw).optJSONArray("candidates")?.optJSONObject(0)?.optJSONObject("content")?.optJSONArray("parts")?.optJSONObject(0)?.optString("text")?:return@withContext null
   AiResponseValidator.parse(txt)
  }} catch(_:Exception){null}
 }
}
