package com.example.geminiai
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.geminiai.core.DemoSignalEngine

private val Bg=Color(0xFF0B1020); private val Panel=Color(0xFF151D31); private val Mint=Color(0xFF55E6B5); private val Muted=Color(0xFF9BA8C7)
class MainActivity:ComponentActivity(){
 override fun onCreate(savedInstanceState:Bundle?){super.onCreate(savedInstanceState);setContent{MaterialTheme(colorScheme=darkColorScheme(primary=Mint,background=Bg,surface=Panel)){Dashboard()}}}
}
@Composable private fun Dashboard(){
 var asset by remember{mutableStateOf("EUR/USD OTC")}; var expiry by remember{mutableStateOf("5 seconds")}
 var auto by remember{mutableStateOf(false)}; var running by remember{mutableStateOf(false)}
 var signal by remember{mutableStateOf("WAIT / NO TRADE")}; var info by remember{mutableStateOf("No live market feed connected. Start analysis for a demo-only signal.") }
 var trades by remember{mutableIntStateOf(0)}; var balance by remember{mutableDoubleStateOf(1000.0)}
 var settings by remember{mutableStateOf(false)}; var key by remember{mutableStateOf("")}
 Column(Modifier.fillMaxSize().background(Bg).verticalScroll(rememberScrollState()).padding(16.dp),verticalArrangement=Arrangement.spacedBy(14.dp)){
  Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically,horizontalArrangement=Arrangement.SpaceBetween){
   Column { Text("GEMINI AI",color=Mint,fontSize=12.sp,fontWeight=FontWeight.Bold); Text("Trading Assistant",color=Color.White,fontSize=25.sp,fontWeight=FontWeight.Bold); Text("Signal lab • demo-first",color=Muted) }
   AssistChip(onClick={settings=!settings},label={Text(if(settings)"Dashboard" else "AI Settings")})
  }
  Card(colors=CardDefaults.cardColors(containerColor=Panel),shape=RoundedCornerShape(20.dp)){Column(Modifier.padding(16.dp),verticalArrangement=Arrangement.spacedBy(10.dp)){
   Text("● OFFLINE / DEMO",color=Mint,fontWeight=FontWeight.Bold,fontSize=12.sp)
   if(settings){Text("Gemini API key",color=Muted);OutlinedTextField(value=key,onValueChange={key=it},label={Text("Paste API key (not sent yet)")},singleLine=true,modifier=Modifier.fillMaxWidth());Text("For production, keep keys on a backend server, not inside a distributed APK.",color=Muted,fontSize=12.sp)}
   else {
    var assetMenu by remember{mutableStateOf(false)}
    Box { OutlinedButton(onClick={assetMenu=true}){Text("Asset: $asset")};DropdownMenu(expanded=assetMenu,onDismissRequest={assetMenu=false}){listOf("EUR/USD OTC","GBP/USD","BTC/USD","GOLD").forEach{DropdownMenuItem(text={Text(it)},onClick={assetMenu=false.also{asset=it})}}} }
    Box(Modifier.fillMaxWidth().height(100.dp).background(Color(0xFF10182A),RoundedCornerShape(12.dp)).padding(12.dp),contentAlignment=Alignment.Center){Text("No authorized live chart feed connected",color=Muted)}
    var expMenu by remember{mutableStateOf(false)}
    Box { OutlinedButton(onClick={expMenu=true}){Text("Trade expiry: $expiry")};DropdownMenu(expanded=expMenu,onDismissRequest={expMenu=false}){listOf("5 seconds","10 seconds","15 seconds","30 seconds","1 minute","5 minutes").forEach{d->DropdownMenuItem(text={Text(d)},onClick={expMenu=false.also{expiry=d}})}}}
   }
  }}
  if(!settings){
   Card(colors=CardDefaults.cardColors(containerColor=Panel),shape=RoundedCornerShape(20.dp)){Column(Modifier.padding(16.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){
    Text("AI SIGNAL",color=Muted,fontSize=12.sp,fontWeight=FontWeight.Bold)
    Text(signal,color=if(signal.startsWith("BUY"))Mint else if(signal.startsWith("SELL"))Color(0xFFFF7C87) else Color.White,fontSize=24.sp,fontWeight=FontWeight.ExtraBold)
    Text(info,color=Muted,fontSize=13.sp)
    Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){Button(onClick={val r=DemoSignalEngine.evaluate();signal=r.direction;info=r.reason;running=true},modifier=Modifier.weight(1f)){Text("Start Analysis")};OutlinedButton(onClick={running=false;auto=false;signal="WAIT / NO TRADE";info="Stopped. Auto trading OFF."},modifier=Modifier.weight(1f)){Text("Stop")}}
    Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween,verticalAlignment=Alignment.CenterVertically){Column{Text("Auto trading",color=Color.White);Text("Demo simulator only",color=Muted,fontSize=11.sp)};Switch(checked=auto,onCheckedChange={auto=it&&running;if(it&&!running)info="Start analysis first. Live order execution is unavailable."})}
    Button(onClick={auto=false;running=false;signal="WAIT / NO TRADE";info="Emergency stop active. No live orders are connected."},colors=ButtonDefaults.buttonColors(containerColor=Color(0xFF8E3143)),modifier=Modifier.fillMaxWidth()){Text("EMERGENCY STOP")}
   }}
   Row(horizontalArrangement=Arrangement.spacedBy(10.dp)){MiniStat("DEMO BALANCE","$"+ "%.2f".format(balance),Modifier.weight(1f));MiniStat("DEMO CYCLES",trades.toString(),Modifier.weight(1f))}
   Button(onClick={val r=DemoSignalEngine.evaluate();signal=r.direction;info="SIMULATED ONLY: "+r.reason;trades++;balance+=if(r.direction.startsWith("BUY"))1.0 else -0.5},modifier=Modifier.fillMaxWidth()){Text("Run one demo cycle")}
   Text("Risk warning: 5-second binary-options-style trading is extremely risky. AI cannot guarantee profit. This app does not connect to Quotex/Pocket Option or place live orders.",color=Color(0xFFFFC76A),fontSize=12.sp)
   Text("Analysis: ${if(running)"ON" else "OFF"} • Expiry: $expiry • $asset",color=Muted,fontSize=11.sp)
  }
 }
}
@Composable private fun MiniStat(label:String,value:String,modifier:Modifier){Card(modifier=modifier,colors=CardDefaults.cardColors(containerColor=Panel),shape=RoundedCornerShape(16.dp)){Column(Modifier.padding(14.dp)){Text(label,color=Muted,fontSize=10.sp,fontWeight=FontWeight.Bold);Text(value,color=Color.White,fontSize=20.sp,fontWeight=FontWeight.Bold)}}}
