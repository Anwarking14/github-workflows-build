package com.example.geminiai.core
import kotlin.random.Random
object DemoSignalEngine {
 fun evaluate():Signal = when(Random.nextInt(100)) {
  in 0..19 -> Signal("BUY / UP (DEMO)","Random demo outcome; no live chart or prices analyzed.")
  in 20..39 -> Signal("SELL / DOWN (DEMO)","Random demo outcome; no live chart or prices analyzed.")
  else -> Signal("WAIT / NO TRADE","No verified market feed. Safe default is to wait.")
 }
}
