# Gemini AI Trading Assistant — Termux starter

## What is included
Kotlin + Jetpack Compose Android project, demo dashboard, expiry selector including 5 seconds, simulated signals, emergency stop, optional Gemini REST client, JSON response validator, risk gate, broker adapter interface, and unit tests.

## Honest limitations
- This is a **demo/signal-only starter**, not a production autonomous trading bot.
- It does not capture other apps' screens or connect to a live market feed.
- No live Quotex or Pocket Option order integration is included. `UnavailableBrokerAdapter` fails closed until an officially supported and authorized broker API is implemented and tested.
- Demo cycles and balance are simulated; never interpret them as actual profit.
- The Gemini client receives a chart description and does not acquire market data itself. Do not distribute API keys in APKs; use a backend proxy in production.
- Binary-options-style 5-second trades are extremely risky; AI does not guarantee winning.

## Build on Termux
1. `pkg update && pkg upgrade`
2. `pkg install openjdk-17 wget unzip git`
3. Install Android SDK command-line tools and platform/build tools 35 for your device. Set `ANDROID_HOME` to the SDK directory.
4. Install compatible Gradle 8.x (AGP 8.7.3) and verify `java -version` and `gradle --version`.
5. In this folder run `gradle assembleDebug`.
6. APK: `app/build/outputs/apk/debug/app-debug.apk`
7. Tests: `gradle testDebugUnitTest`

Termux SDK setup differs by device. If Android SDK tooling fails, open the project in Android Studio on a desktop with JDK 17 and Android SDK 35.

## Troubleshooting
- SDK missing: check `ANDROID_HOME`, `platforms/android-35`, and build-tools 35.
- Compose build fails: use JDK 17 and compatible Gradle 8.x.
- Gemini request fails: verify key, quota, current model availability, network, and JSON response.
- Broker shows unavailable: expected until an official authorized API adapter is implemented.
